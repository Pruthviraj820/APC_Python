n=int(input("Enter a number"))
while n>=0:
    print(n)