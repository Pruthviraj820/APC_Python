n=int(input("Enter a number"))
sum = 0
cnt = 1
while cnt<=n:
    sum+=cnt
    cnt+=2
print(sum)