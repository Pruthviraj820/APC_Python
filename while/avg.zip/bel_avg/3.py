n=int(input("Enter a number"))
cnt=1
while cnt<=n:
    print(cnt)
    cnt+=2