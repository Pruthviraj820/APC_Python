n=int(input("Enter a number"))
cnt=0
while cnt<=n:
    print(cnt)
    cnt+=2